﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using SimulatedDevice.Model;
using System.Configuration;

namespace SimulatedDevice
{
    class Program
    {

        static DeviceClient deviceClient;
        static string iotHubUri = ConfigurationManager.AppSettings["iotHubName"];
        static string deviceId = ConfigurationManager.AppSettings["deviceId"];
        static string deviceKey = ConfigurationManager.AppSettings["deviceKey"];


        static void Main(string[] args)
        {
            Console.WriteLine("Simulated device\n");
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(deviceId, deviceKey), TransportType.Mqtt);

            SendDeviceToCloudMessagesAsync();
            Console.ReadLine();
        }

        private static async void SendDeviceToCloudMessagesAsync()
        {
         
            Random rand = new Random();
            var categories = SampleData.GetCategories().ToList();
            var products = SampleData.GetProducts(categories).ToList();
            var eventTypes = new List<string>() { "add", "view", "checkout", "remove" };
            var eventWeight = new List<int>() { 32, 54, 20, 10 };


            while (true)
            {
            
                var userId = rand.Next(1, 250).ToString();
                var eventNum = GetRandomEventNum(eventTypes.Count, eventWeight);
                var randomProduct = products[rand.Next(0, products.Count)];
                var randomEventType = eventTypes[eventNum];
                var eventMessage = new EventMessage();
                var qty = rand.Next(1, 4);

                if (randomEventType.Equals("checkout"))
                {
                     eventMessage = new EventMessage
                    {
                        EventDate = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                        UserId = userId.ToString(),
                        Type = randomEventType,
                        ProductId = randomProduct.ProductId.ToString(),
                        quantity = qty,
                        Price = (randomProduct.SalePrice * qty)
                    };
                }
                else
                {
                    eventMessage = new EventMessage
                    {
                        EventDate = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                        UserId = userId.ToString(),
                        Type = randomEventType,
                        ProductId = randomProduct.ProductId.ToString()
                    };
                }
              
                var messageString = JsonConvert.SerializeObject(eventMessage);
                var message = new Message(Encoding.ASCII.GetBytes(messageString));

                await deviceClient.SendEventAsync(message);
                Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, messageString);

                Task.Delay(1000).Wait();
            }
        }

        private static int GetRandomEventNum(int num_choices, List<int> choice_weight)
        {
            Random rand = new Random();

            int sum_of_weight = 0;
            for (int i = 0; i < num_choices; i++)
            {
                sum_of_weight += choice_weight[i];
            }

            int rnd = rand.Next(sum_of_weight);
            for (int i = 0; i < num_choices; i++)
            {
                if (rnd < choice_weight[i])
                    return i;
                rnd -= choice_weight[i];
            }

            return 1;
        }

    }
}
